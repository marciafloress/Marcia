export * from './cadastrar-pj.component';
