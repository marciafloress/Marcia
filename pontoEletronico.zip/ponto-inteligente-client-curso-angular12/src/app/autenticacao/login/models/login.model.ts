
export class Login {
	constructor(
		public email: string,
		public senha: string) {}
}
